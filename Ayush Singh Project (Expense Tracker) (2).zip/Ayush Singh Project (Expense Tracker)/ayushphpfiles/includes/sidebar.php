<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>


<div id="sidebar-collapse " class="col-sm-3 col-lg-2 sidebar">
        <div class="profile-sidebar ">
            <div class="profile-userpic">
                <img src="https://lh3.googleusercontent.com/a/ACg8ocJDO_48rTGyuekqx6H_cckYjCa_Y82bS0MLq5WchvlTJNOzSGs=s360-c-no" class="img-responsive" alt="profile_photo">
            </div>
            <div class="profile-usertitle">
                <?php
$uid=$_SESSION['detsuid'];
$ret=mysqli_query($con,"select FullName from tbluser where ID='$uid'");
$row=mysqli_fetch_array($ret);
$name=$row['FullName'];

?>
                <div class="profile-usertitle-name color-gray"><?php echo $name; ?></div>
                <div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="divider"></div>
        
        <ul class="nav menu">
            <li class="active"><a href="dash.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
            
            <li><a href="profile.php"><em class="fa fa-user">&nbsp;</em> Profile</a></li>

            <li class="parent "><a data-toggle="collapse" href="#sub-item-1">
                <em class="fa fa-navicon">&nbsp;</em>Expenses <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"></span>
                </a>
                <ul class="children collapse" id="sub-item-1">
                    <li><a class="" href="add_expense.php">
                        <span class="fa fa-minus">&nbsp;</span> Add Expenses
                    </a></li>
                    <li><a class="" href="manage_expense.php">
                        <span class="fa fa-minus">&nbsp;</span> Manage Expenses
                    </a></li>
                    
                </ul>

            </li>

            <li class="parent "><a data-toggle="collapse" href="#sub-item-2">
                <em class="fa fa-navicon">&nbsp;</em>Expense Report <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"></span>
                </a>
                <ul class="children collapse" id="sub-item-2">
                    <li><a class="" href="datewise_expense.php">
                        <span class="fa fa-minus">&nbsp;</span> Daywise Expenses
                    </a></li>
                    <li><a class="" href="monthly_expense.php">
                        <span class="fa fa-minus">&nbsp;</span> Monthwise Expenses
                    </a></li>
                    <li><a class="" href="yearly_expense.php">
                        <span class="fa fa-minus">&nbsp;</span> Yearwise Expenses
                    </a></li>
                    
                </ul>
            </li>

<li><a href="change_password.php"><em class="fa fa-clone">&nbsp;</em> Change Password</a></li>
<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>

        </ul>
    </div>