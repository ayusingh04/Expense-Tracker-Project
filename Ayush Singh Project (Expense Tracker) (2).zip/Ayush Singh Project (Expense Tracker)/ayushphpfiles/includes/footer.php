<div class="col-sm-12">
				<p class="ya color-gray" align="center"> Expense Tracker Powered by @ Ayush Singh</p>
			</div>